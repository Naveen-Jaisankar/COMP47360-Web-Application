### **purple_air_quality.csv**

1. **time_stamp**: Unix timestamp indicating when the data was recorded. This is the number of seconds since January 1, 1970.
2. **sensor_index**: A unique identifier for each sensor that collected the data.
3. **humidity**: The humidity level at the time of recording, represented as a percentage.
4. **temperature**: The temperature in degrees Fahrenheit at the time of recording.
5. **visual_range**: A measure of visibility in meters, indicating how clear the air is.
6. **pm2.5_atm**: Concentration of PM2.5 particles in the atmosphere, not important as it is too technical.
7. **datetime**: A human-readable date and time format for when the data was recorded. Directly related to `time_stamp`.
8. **pm2.5_aqi**: Important! The Air Quality Index value calculated based on the PM2.5 concentration, which indicates the level of air pollution. Directly related to `pm2.5_atm`.

### **sensor_info.csv**

1. **sensor_index**: A unique identifier for each sensor that collected the data.
2. **name**: The name or designation given to the sensor location.
3. **model**: The model of the sensor, indicating the type of device used for measuring air quality.
4. **latitude**: The latitude coordinate of the sensor's location.
5. **longitude**: The longitude coordinate of the sensor's location.
6. **altitude**: The altitude in meters where the sensor is located.
7. **date_created**: Unix timestamp indicating when the sensor was installed.
8. **in_manhattan**: A binary indicator (1 for yes, 0 for no) showing whether the sensor is located in Manhattan, added by myself.
